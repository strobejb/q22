Array column comparison
=======================

Each colour folder contains:
- array-vertical-column.svg
- array-diagonal-column.svg

The diagonal version is the direct small-resolution counterpart to the vertical column:
three separate mini-diamond tiles stepping down-right.
